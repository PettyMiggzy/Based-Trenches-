// Trench Guard — background service worker

const BT_DOMAINS   = ['basedtrenches.fun', 'www.basedtrenches.fun', 'basedtrenches.co']
const SCAM_KEYWORDS = [
  'basedtrenches-', 'based-trenches-', 'basedtrenchess',
  'trenchguard-', 'pump.fun-', 'uniswap-app-',
  'metamask-secure', 'wallet-connect-', 'claim-airdrop',
]

chrome.runtime.onInstalled.addListener(async () => {
  console.log('Trench Guard installed')
  // Set install date for trial tracking
  const data = await chrome.storage.local.get(['installDate'])
  if (!data.installDate) {
    await chrome.storage.local.set({ installDate: Date.now() })
  }
})

// Watch navigation for scam sites
chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0) return // main frame only
  try {
    const url    = new URL(details.url)
    const domain = url.hostname.toLowerCase()
    const isScam = SCAM_KEYWORDS.some(kw => domain.includes(kw))
    
    if (isScam) {
      // Show notification
      chrome.notifications.create({
        type:    'basic',
        iconUrl: '../icons/icon48.png',
        title:   '⚠ Trench Guard Alert',
        message: `Suspicious site detected: ${domain} — Do not connect your wallet!`,
        priority: 2,
      })

      // Save to alerts
      const data   = await chrome.storage.local.get(['alerts'])
      const alerts = data.alerts || []
      alerts.unshift({ site: domain, msg: 'Suspicious domain — possible phishing', time: Date.now() })
      await chrome.storage.local.set({ alerts: alerts.slice(0, 20) })
    }
  } catch (_) {}
})

// Handle messages
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg.type === 'GET_CURRENT_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      respond({ tab: tabs[0] })
    })
    return true
  }
})
