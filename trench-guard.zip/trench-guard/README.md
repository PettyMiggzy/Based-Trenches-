# Trench Guard — Chrome Extension

Wallet protection for Base Chain. Free 30-day trial, then 0.004 ETH/month.

## Setup (Developer Mode)

1. Download and unzip this folder
2. Open Chrome → chrome://extensions
3. Toggle ON "Developer mode"
4. Click "Load unpacked" → select this folder (trench-guard)
5. The 🛡 icon will appear in your toolbar

## Features

### Free (30-day trial)
- Scam site detection and warnings
- Phishing domain alerts
- Unlimited approval transaction warnings
- Based Trenches verified badge
- Contract scanner

### Pro (0.004 ETH/month on Base ≈ $9)
- Honeypot detection before you buy
- Rug pull early warning system
- Contract audit scores
- Whale wallet tracker
- Priority Based Trenches alerts

## Payment System
- User pays 0.004 ETH to platform wallet on Base
- Extension verifies payment on-chain
- Pro unlocks immediately after confirmation
- 31-day access granted per payment
- No signup, no account, fully trustless

## Publishing to Chrome Web Store
1. https://chrome.google.com/webstore/devconsole
2. $5 one-time developer fee
3. New Item → Upload zip of this folder
4. Submit for review

## Revenue
At $9/month per user:
- 100 users = $900/month
- 500 users = $4,500/month
- 1000 users = $9,000/month
All paid in ETH directly to your wallet.
