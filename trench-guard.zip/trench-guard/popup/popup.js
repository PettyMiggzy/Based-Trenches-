// Trench Guard — popup.js
// Subscription: 30-day free trial, then 0.004 ETH/month on Base

const PLATFORM_WALLET = '0xB9d4B73bE18914c6d64Bee65a806648370be467f'
const BASE_RPC         = 'https://mainnet.base.org'
const MONTHLY_FEE      = '0xE35FA931A000' // 0.004 ETH in hex
const SITE_URL         = 'https://basedtrenches.fun'
const BT_DOMAINS       = ['basedtrenches.fun', 'www.basedtrenches.fun', 'basedtrenches.co', 'www.basedtrenches.co']

// Known scam patterns (expand over time)
const SCAM_KEYWORDS = [
  'basedtrenches-', 'based-trenches-', 'basedtrench-', 'basedtrenchess',
  'trenchguard-', 'trench-guard-', 'pump.fun-', 'uniswap-app',
  'metamask-secure', 'wallet-connect-', 'claim-airdrop', 'connect-wallet-',
]

const $ = id => document.getElementById(id)

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  setupTabs()
  await checkSubscription()
  await checkCurrentSite()
  loadAlerts()
  setupButtons()
})

// ── Tabs ──────────────────────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'))
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'))
      tab.classList.add('active')
      $('tab-' + tab.dataset.tab).classList.add('active')
    })
  })
}

// ── Subscription check ────────────────────────────────────────────────────────
async function checkSubscription() {
  const data = await chrome.storage.local.get(['installDate', 'walletAddress', 'proExpiry'])

  // Set install date if first run
  if (!data.installDate) {
    await chrome.storage.local.set({ installDate: Date.now() })
    data.installDate = Date.now()
  }

  const now         = Date.now()
  const trialDays   = 30
  const elapsed     = Math.floor((now - data.installDate) / 86400000)
  const trialLeft   = Math.max(0, trialDays - elapsed)
  const proExpiry   = data.proExpiry || 0
  const isPro       = proExpiry > now
  const trialActive = trialLeft > 0

  // Update UI
  if (isPro) {
    const daysLeft = Math.ceil((proExpiry - now) / 86400000)
    $('sub-status').textContent = `⚡ PRO · ${daysLeft} days left`
    $('sub-status').style.color = 'var(--gold)'
    $('plan-chip').textContent = 'PRO'
    $('plan-chip').className = 'plan-chip pro'
    $('days-left').textContent = `${daysLeft} days`
    $('upgrade-card').style.display = 'none'
    unlockProFeatures()
  } else if (trialActive) {
    $('sub-status').textContent = `Free trial · ${trialLeft} days left`
    $('btn-upgrade').style.display = 'block'
    $('plan-chip').textContent = 'FREE TRIAL'
    $('days-left').textContent = `${trialLeft} days`
  } else {
    $('sub-status').textContent = `⚠ Trial expired — upgrade to continue`
    $('sub-status').style.color = 'var(--red)'
    $('btn-upgrade').style.display = 'block'
    $('plan-chip').textContent = 'EXPIRED'
    $('plan-chip').style.color = 'var(--red)'
    $('days-left').textContent = '0 days'
  }

  // Settings wallet
  if (data.walletAddress) {
    $('settings-wallet').textContent = data.walletAddress.slice(0,8) + '...' + data.walletAddress.slice(-4)
  }
}

function unlockProFeatures() {
  ;['icon-honeypot','icon-rug','icon-whale','icon-audit'].forEach(id => {
    const el = $(id)
    if (el) { el.textContent = '✓'; el.className = 'check-icon on' }
  })
}

// ── Current site check ────────────────────────────────────────────────────────
async function checkCurrentSite() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab?.url) return

  try {
    const url    = new URL(tab.url)
    const domain = url.hostname.toLowerCase()
    $('current-site-url').textContent = domain

    // Check if Based Trenches official site
    if (BT_DOMAINS.includes(domain)) {
      $('site-verdict').textContent = '✓ Official Based Trenches site'
      $('site-verdict').className = 'verdict safe'
      $('guard-badge').textContent = '● SAFE'
      $('guard-badge').className = 'badge safe'
      $('bt-badge-card').style.display = 'flex'
      return
    }

    // Check for scam keywords
    const isScam = SCAM_KEYWORDS.some(kw => domain.includes(kw) || tab.url.toLowerCase().includes(kw))
    if (isScam) {
      $('site-verdict').textContent = '⚠ POSSIBLE SCAM — Do not connect wallet'
      $('site-verdict').className = 'verdict danger'
      $('guard-badge').textContent = '● DANGER'
      $('guard-badge').className = 'badge danger'
      saveAlert(domain, 'Suspicious domain detected — possible phishing site')
      return
    }

    // Check for common DeFi scam patterns
    const scamPatterns = [
      /airdrop.*claim/i, /claim.*airdrop/i, /free.*eth/i,
      /wallet.*drainer/i, /connect.*earn/i, /metamask.*verify/i,
    ]
    const pageScam = scamPatterns.some(p => p.test(tab.title || '') || p.test(tab.url))
    if (pageScam) {
      $('site-verdict').textContent = '⚠ WARNING — Suspicious page content'
      $('site-verdict').className = 'verdict warning'
      $('guard-badge').textContent = '● WARNING'
      $('guard-badge').className = 'badge warning'
      return
    }

    $('site-verdict').textContent = '✓ No threats detected'
    $('site-verdict').className = 'verdict safe'
    $('guard-badge').textContent = '● SAFE'
    $('guard-badge').className = 'badge safe'
  } catch (_) {}
}

// ── Contract scanner ──────────────────────────────────────────────────────────
async function scanContract() {
  const address = $('scan-address').value.trim()
  if (!address || !address.startsWith('0x') || address.length !== 42) {
    $('scan-results').innerHTML = '<div class="scan-result warning"><div class="scan-title" style="color:var(--gold)">Invalid address</div></div>'
    return
  }

  $('scan-results').innerHTML = '<div class="scan-result"><div class="scan-title" style="color:var(--gold)">Scanning...</div></div>'

  try {
    // Get basic contract info from Base RPC
    const [code, balance] = await Promise.all([
      rpcCall('eth_getCode', [address, 'latest']),
      rpcCall('eth_getBalance', [address, 'latest']),
    ])

    const isContract   = code && code !== '0x'
    const ethBalance   = parseInt(balance || '0x0', 16) / 1e18
    const hasCode      = isContract

    // Basic heuristics
    const codeLen   = (code?.length - 2) / 2 // bytes
    const isTiny    = codeLen < 100
    const isLarge   = codeLen > 10000

    let riskLevel = 'safe'
    let findings  = []

    if (!hasCode) {
      findings.push({ k: 'Type', v: 'Wallet / EOA', c: 'green' })
    } else {
      findings.push({ k: 'Type', v: 'Smart Contract', c: 'green' })
      findings.push({ k: 'Code size', v: `${codeLen} bytes`, c: '' })

      if (isTiny) {
        findings.push({ k: 'Warning', v: 'Very small contract', c: 'gold' })
        riskLevel = 'warning'
      }

      // Check for Based Trenches factory/curve
      const knownContracts: Record<string, string> = {
        '0xa8b68ebc490f215c44c37987c9eb36741aaf882c': '✓ BT Factory (Verified)',
        '0xe8ec7f7935870e4fae26ab689105c60d673ca023': '✓ BT ProtocolVault (Verified)',
        '0x34fa3e260484063cd9988380dd581642fc15c0bc': '✓ BT WarChest (Verified)',
      }

      const known = knownContracts[address.toLowerCase()]
      if (known) {
        findings.push({ k: 'Identity', v: known, c: 'green' })
        riskLevel = 'safe'
      }
    }

    findings.push({ k: 'ETH Balance', v: `${ethBalance.toFixed(4)} ETH`, c: '' })
    findings.push({ k: 'Address', v: `${address.slice(0,8)}...${address.slice(-6)}`, c: '' })

    const colors: Record<string, string> = { safe: 'var(--green)', warning: 'var(--gold)', danger: 'var(--red)' }
    const titles: Record<string, string> = { safe: '✓ Looks Clean', warning: '⚠ Review Carefully', danger: '✗ High Risk' }

    $('scan-results').innerHTML = `
      <div class="scan-result ${riskLevel}">
        <div class="scan-title" style="color:${colors[riskLevel]}">${titles[riskLevel]}</div>
        ${findings.map(f => `<div class="scan-row"><span class="scan-key">${f.k}</span><span class="scan-val ${f.c}">${f.v}</span></div>`).join('')}
      </div>
    `
  } catch (e) {
    $('scan-results').innerHTML = `<div class="scan-result warning"><div class="scan-title" style="color:var(--gold)">Scan failed</div><div style="font-size:11px;color:var(--grey-l);margin-top:6px">${e.message}</div></div>`
  }
}

// ── Payment ───────────────────────────────────────────────────────────────────
async function payForPro() {
  if (!window.ethereum) {
    alert('No wallet detected. Install MetaMask or Coinbase Wallet.')
    return
  }

  try {
    // Switch to Base
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: '0x2105' }]
    }).catch(async (e: any) => {
      if (e.code === 4902) {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{ chainId: '0x2105', chainName: 'Base', nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 }, rpcUrls: ['https://mainnet.base.org'], blockExplorerUrls: ['https://basescan.org'] }]
        })
      }
    })

    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' })
    const wallet   = accounts[0]

    $('btn-pay').textContent    = 'CONFIRMING...'
    $('btn-pay').disabled       = true

    const txHash = await window.ethereum.request({
      method: 'eth_sendTransaction',
      params: [{
        from:  wallet,
        to:    PLATFORM_WALLET,
        value: MONTHLY_FEE,
        data:  '0x' + Buffer.from('TrenchGuard Pro', 'utf8').toString('hex'),
      }]
    })

    // Wait for confirmation
    $('btn-pay').textContent = 'VERIFYING ON CHAIN...'
    let receipt = null
    for (let i = 0; i < 30; i++) {
      await sleep(2000)
      receipt = await window.ethereum.request({ method: 'eth_getTransactionReceipt', params: [txHash] })
      if (receipt) break
    }

    if (receipt?.status === '0x1') {
      const expiry = Date.now() + 31 * 24 * 60 * 60 * 1000 // 31 days
      await chrome.storage.local.set({ walletAddress: wallet, proExpiry: expiry })
      $('btn-pay').textContent = '✓ PRO ACTIVATED!'
      await checkSubscription()
      unlockProFeatures()
    } else {
      $('btn-pay').textContent = 'TX FAILED — TRY AGAIN'
      $('btn-pay').disabled = false
    }
  } catch (e: any) {
    if (e.code === 4001) {
      $('btn-pay').textContent = 'CANCELLED'
    } else {
      $('btn-pay').textContent = 'ERROR — TRY AGAIN'
    }
    $('btn-pay').disabled = false
    setTimeout(() => {
      $('btn-pay').textContent = 'PAY 0.004 ETH ON BASE'
      $('btn-pay').disabled = false
    }, 2000)
  }
}

// ── Alerts ────────────────────────────────────────────────────────────────────
async function loadAlerts() {
  const data = await chrome.storage.local.get(['alerts'])
  const alerts = data.alerts || []
  if (alerts.length === 0) return

  $('alert-list').innerHTML = alerts.slice(0, 5).map((a: any) => `
    <div class="alert-item">
      <div class="alert-site">⚠ ${a.site}</div>
      <div class="alert-msg">${a.msg}</div>
    </div>
  `).join('')
}

async function saveAlert(site: string, msg: string) {
  const data   = await chrome.storage.local.get(['alerts'])
  const alerts = data.alerts || []
  alerts.unshift({ site, msg, time: Date.now() })
  await chrome.storage.local.set({ alerts: alerts.slice(0, 20) })
}

// ── RPC call ──────────────────────────────────────────────────────────────────
async function rpcCall(method: string, params: any[]) {
  const res  = await fetch(BASE_RPC, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params })
  })
  const data = await res.json()
  return data.result
}

// ── Buttons ───────────────────────────────────────────────────────────────────
function setupButtons() {
  $('btn-upgrade').onclick    = () => { document.querySelector('[data-tab="settings"]').click() }
  $('btn-scan').onclick       = scanContract
  $('btn-pay').onclick        = payForPro
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)) }
