// Trench Guard — content script
// Runs on every page, watches for wallet drain attempts

const BT_DOMAINS = ['basedtrenches.fun', 'www.basedtrenches.fun', 'basedtrenches.co', 'www.basedtrenches.co']

;(function() {
  const domain = window.location.hostname.toLowerCase()
  const isBT   = BT_DOMAINS.includes(domain)

  // Inject verified badge on Based Trenches official site
  if (isBT) {
    const badge       = document.createElement('div')
    badge.id          = 'bt-guard-badge'
    badge.innerHTML   = '🛡 Trench Guard Verified'
    badge.style.cssText = `
      position: fixed; bottom: 16px; right: 16px; z-index: 999999;
      background: rgba(6,5,4,0.95); border: 1px solid rgba(58,153,72,0.5);
      color: #3a9948; font-family: 'Oswald', sans-serif; font-size: 11px;
      font-weight: 700; padding: 6px 14px; letter-spacing: 0.08em;
      pointer-events: none; opacity: 0; transition: opacity 0.5s;
    `
    document.addEventListener('DOMContentLoaded', () => {
      document.body.appendChild(badge)
      setTimeout(() => { badge.style.opacity = '1' }, 1000)
      setTimeout(() => { badge.style.opacity = '0' }, 4000)
    })
  }

  // Watch for suspicious transaction requests
  if (window.ethereum) {
    const originalRequest = window.ethereum.request.bind(window.ethereum)
    window.ethereum.request = async function(args) {
      // Flag unlimited token approvals
      if (args.method === 'eth_sendTransaction') {
        const data = args.params?.[0]?.data || ''
        // approve(address,uint256) with max uint256 = potential drain
        if (data.startsWith('0x095ea7b3') && data.endsWith('f'.repeat(64))) {
          const confirmed = confirm(
            '⚠ TRENCH GUARD WARNING\n\n' +
            'This transaction requests UNLIMITED token approval.\n' +
            'This is commonly used by token drainers.\n\n' +
            'Are you sure you want to proceed?'
          )
          if (!confirmed) throw new Error('Transaction blocked by Trench Guard')
        }
      }
      return originalRequest(args)
    }
  }
})()
